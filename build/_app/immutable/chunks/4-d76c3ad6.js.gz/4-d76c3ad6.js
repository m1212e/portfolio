import{default as t}from"../components/pages/privacy/_page.svelte-0b75ff5f.js";export{t as component};
