import{default as t}from"../components/error.svelte-f4ab96ef.js";export{t as component};
