const t=""+new URL("../assets/dark-github-7a0dd11e.svg",import.meta.url).href;export{t as G};
