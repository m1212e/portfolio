import{default as t}from"../components/pages/imprint/_page.svelte-c067737c.js";export{t as component};
